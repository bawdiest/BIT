# Migrationskonzept

# Ist Analyse
## Verwendete Queries (durch EZV)
### BW - P10
* 
RRMX - 40_Kreditbelastung ungleich Kreditableitung FMDERIVER

    + Query: 
JE_ICFMQ_Q_100_002_7

    + MultiCube: 
JE_ICFMQ (DSO!)

    + DataSource: 
0PU_IS_PS_32

 * 
RRMX - 10_Finanzreporting nach Krediten / KLAR-Objekten (BPS, CO)

    + Query: 
JE_MCOPL_T_1_10_2_08_055_V01_7

    + MultiCube: 
JE_MCOPL

    + DataSource: 
JE_IS_KONS_STAT (CSV), 0PU_IS_PS_11, 0PU_IS_PS_31, 0PU_IS_PS_32, 0CO_OM_CCA_9, 0CO_OM_CCA_10, 0CO_OM_OPA_6, ZJE_B_BSEG (BSEG Tabelle nur bis 2013), 3EC_CS_1A (EC-CS), 0FI_AP_4, 0FI_AP_6, 0FI_AR_4, 0FI_AR_6, 0FI_GL_6, 0RE_5, JE_IS_MASSEN_BPS3, JE_IS_RELOAD_BPS3, JE_ICBPS3 (Transaktionaler InfoCube), ZJE_S_FMDERIVE, 0CO_OM_CCA_1, 0CO_OM_OPA_7, 0CO_OM_WBS_6, 0CO_OM_WBS_7, 0CO_OM_OPA_1, 0CO_OM_WBS_1, 0REFX_3

 * 
SAP_BW_QUERY - Mittelflussrechnung / FMFR (FI)

    + Query: 
JE_MCOPL_T_1_10_2_04_050_V02_7

    + MultiCube: 
JE_MCOPL

    + DataSource: 
JE_IS_KONS_STAT (CSV), 0PU_IS_PS_11, 0PU_IS_PS_31, 0PU_IS_PS_32, 0CO_OM_CCA_9, 0CO_OM_CCA_10, 0CO_OM_OPA_6, ZJE_B_BSEG (BSEG Tabelle nur bis 2013), 3EC_CS_1A (EC-CS), 0FI_AP_4, 0FI_AP_6, 0FI_AR_4, 0FI_AR_6, 0FI_GL_6, 0RE_5, JE_IS_MASSEN_BPS3, JE_IS_RELOAD_BPS3, JE_ICBPS3 (Transaktionaler InfoCube), ZJE_S_FMDERIVE, 0CO_OM_CCA_1, 0CO_OM_OPA_7, 0CO_OM_WBS_6, 0CO_OM_WBS_7, 0CO_OM_OPA_1, 0CO_OM_WBS_1, 0REFX_3

 * 
SAP_BW_QUERY - Prufbericht Referenzableitung

    + Query: 
JE_MCOPL_T_1_10_2_03_034_V01_7

    + MultiCube: 
JE_MCOPL

    + DataSource: 
JE_IS_KONS_STAT (CSV), 0PU_IS_PS_11, 0PU_IS_PS_31, 0PU_IS_PS_32, 0CO_OM_CCA_9, 0CO_OM_CCA_10, 0CO_OM_OPA_6, ZJE_B_BSEG (BSEG Tabelle nur bis 2013), 3EC_CS_1A (EC-CS), 0FI_AP_4, 0FI_AP_6, 0FI_AR_4, 0FI_AR_6, 0FI_GL_6, 0RE_5, JE_IS_MASSEN_BPS3, JE_IS_RELOAD_BPS3, JE_ICBPS3 (Transaktionaler InfoCube), ZJE_S_FMDERIVE, 0CO_OM_CCA_1, 0CO_OM_OPA_7, 0CO_OM_WBS_6, 0CO_OM_WBS_7, 0CO_OM_OPA_1, 0CO_OM_WBS_1, 0REFX_3

 * 
SAP_BW_QUERY - Sicherheiten nach Debitor u Beleg

    + Query: 
KH_MCSIC_600_Q011

    + MultiCube: 
KH_ICSICB (InfoCube)

    + DataSource: 
ZKH_B_SICB_KORREKTUR, ZKH_B_SICB

 * 
RRMX - Liste Einzelposten Sachkonto Profitcenter (neu)

    + Query: 
KH_MCBSBC_Q002_7, KH_MCBSBC_Q001

    + MultiCube: 
KH_MCBSBC

    + DataSource: 
ZKH_B_BSIS (BSIS Tabelle), ZKH_B_BSAS (BSAS Tabelle)

 * 
RRMX - Monatsabschluss (7.x)

    + Query: 
KH_KH_MCEZV_Q002_7

    + MultiCube: 
KH_MCEZV

    + DataSource: 
ZJE_B_GLPCP

 * 
RRMX - Einnahmeubersicht

    + Query: 
KH_MCEZV_Q_101_EINNAHMEN_EZV

    + MultiCube: 
KH_MCEZV

    + DataSource: 
ZJE_B_GLPCP

 * 
RRMX - Liste Erhebungskosten

    + Query: 
KH_MCEZV_100_Q001

    + MultiCube: 
KH_MCEZV

    + DataSource: 
ZJE_B_GLPCP

 * 
RRMX - Bussenverteiler

    + Query: 
KH_KH_MCEZV_Q001_7, KH_KH_MCEZV_Q003_7

    + MultiCube: 
KH_MCEZV

    + DataSource: 
ZJE_B_GLPCP

 * 
RRMX - Abgleich SI-Verwaltung und Sachkonto

    + Query: 
KH_MCSIC_600_Q011

    + MultiCube: 
KH_MCFIEP

    + DataSource: 
0FI_AP_4, 0FI_AR_4, 0FI_GL_4

 * 
SAP_BW_QUERY - Hauptbuch EP Sicherheiten

    + Query: 
KH_MCSIC_600_Q012

    + MultiCube: 
KH_MCFIEP

    + DataSource: 
0FI_AP_4, 0FI_AR_4, 0FI_GL_4

 * 
RRMX - Debitoren Masterquery

    + Query: 
KH_MCMD_Q001

    + MultiCube: 
KH_MCMD

    + DataSource: 
ZKH_B_FIRE_DEBITORENDATEN

 * 
RRMX - Barhinterlagen Kontrolle detailliert

    + Query: 
KH_MCSCHV_Q016

    + MultiCube: 
KH_MCSCHV

    + DataSource: 
ZKH_B_SKO, ZKH_B_SNT, ZKH_B_VKDFS, 0FI_GL_4, ZKH_B_SPOH

 * 
RRMX - Masterquery Verteilung Sicherheiten nach Verwendungszweck (N

    + Query: 
KH_MCSIC_600_Q006

    + MultiCube: 
KH_MCSIC

    + DataSource: 
ZKH_B_SICV, ZKH_B_SICB_KORREKTUR, ZKH_B_FIRE_DEBITORENDATEN, ZKH_B_SICM, ZKH_B_SICA, ZKH_B_SICB

 * 
RRMX - Masterquery Mahndaten

    + Query: 
KH_MCSIC_600_Q004

    + MultiCube: 
KH_MCSIC

    + DataSource: 
ZKH_B_SICV, ZKH_B_SICB_KORREKTUR, ZKH_B_FIRE_DEBITORENDATEN, ZKH_B_SICM, ZKH_B_SICA, ZKH_B_SICB

 * 
RRMX - Masterquery Sicherheiten Multiprovider

    + Query: 
KH_MCSIC_600_Q001

    + MultiCube: 
KH_MCSIC

    + DataSource: 
ZKH_B_SICV, ZKH_B_SICB_KORREKTUR, ZKH_B_FIRE_DEBITORENDATEN, ZKH_B_SICM, ZKH_B_SICA, ZKH_B_SICB

 * 
RRMX - Masterquery Verteilung Sicherheiten nach Verwendungszweck

    + Query: 
KH_MCSIC_600_Q005

    + MultiCube: 
KH_MCSIC

    + DataSource: 
ZKH_B_SICV, ZKH_B_SICB_KORREKTUR, ZKH_B_FIRE_DEBITORENDATEN, ZKH_B_SICM, ZKH_B_SICA, ZKH_B_SICB

 * 
RRMX - Masterquery Sicherheiten

    + Query: 
KH_MCSIC_600_Q002

    + MultiCube: 
KH_MCSIC

    + DataSource: 
ZKH_B_SICV, ZKH_B_SICB_KORREKTUR, ZKH_B_FIRE_DEBITORENDATEN, ZKH_B_SICM, ZKH_B_SICA, ZKH_B_SICB

 * 
RRMX - Masterquery Sicherheiten Kopf und Position

    + Query: 
KH_MCSIC_600_Q003

    + MultiCube: 
KH_MCSIC

    + DataSource: 
ZKH_B_SICV, ZKH_B_SICB_KORREKTUR, ZKH_B_FIRE_DEBITORENDATEN, ZKH_B_SICM, ZKH_B_SICA, ZKH_B_SICB


### Portal
- Kassenbuchjournal
- Dienststellenabschluss
- Barhinterlagen Kontrolle

## Status Datenflüsse auf x91
Wenn eine Datenquelle bereits auf x91 angeschlossen ist, bedeutet dies, dass nur die EZV spezifische Business Logik samt Queries migriert werden muss.  Falls die DataSource noch nicht angeschlossen ist, muss der Datenfluss komplett neu und nach Architekturvorgaben gebaut werden.

**Grobe Schätzung: **  

- Datenfluss muss komplett neu aufgebaut werden: 1x DSO Entry Layer 


 ID  DataSource                               Auf.x91.bis.H.Layer 
---  ---------------------------------------  --------------------
  1  JE_IS_KONS_STAT (CSV)                                        
  2  ZJE_B_BSEG (BSEG Tabelle nur bis 2013)                       
  3  3EC_CS_1A (EC-CS)                                            
  4  0FI_AP_4                                                     
  5  0FI_AP_6                                                     
  6  0FI_AR_4                                                     
  7  0FI_AR_6                                                     
  8  0FI_GL_6                                                     
  9  0PU_IS_PS_11                             x                   
 10  0PU_IS_PS_31                             x                   
 11  0PU_IS_PS_32                             x                   
 12  0CO_OM_CCA_9                             x                   
 13  0CO_OM_CCA_10                            x                   
 14  0CO_OM_OPA_6                             x                   
 15  0CO_OM_OPA_7                             x                   
 16  0CO_OM_WBS_6                             x                   
 17  0CO_OM_WBS_7                             x                   
 18  0CO_OM_CCA_1                             x                   
 19  0CO_OM_OPA_1                             x                   
 20  0CO_OM_WBS_1                             x                   
 21  0REFX_3                                                      
 22  0RE_5                                                        
 23  JE_IS_MASSEN_BPS3                                            
 24  JE_IS_RELOAD_BPS3                                            
 25  JE_ICBPS3 (Transaktionaler InfoCube)                         
 26  ZJE_S_FMDERIVE                                               
 27  ZJE_B_GLPCP                                                  
 28  ZKH_B_VKDFS                                                  
 29  0FI_GL_4                                 x                   
 30  ZKH_B_SKO                                                    
 31  ZKH_B_SNT                                                    
 32  ZKH_B_SPOH                                                   
 33  ZKH_B_BSAS (BSAS Tabelle)                                    
 34  ZKH_B_BSIS (BSIS Tabelle)                                    
 35  ZKH_B_FIRE_DEBITORENDATEN                                    
 36  ZKH_B_SICM                                                   
 37  ZKH_B_SICA                                                   
 38  ZKH_B_SICB                                                   
 39  ZKH_B_SICB_KORREKTUR                                         
 40  ZKH_B_SICV                                                   



# Varianten
## Variante 1: FIRE und LSVA zusammen migrieren
Eher unwahrscheinlich bis Ende 2016

## Variante 2: LSVA im Alleingang migrieren
Es werden nur LSVA relevante Teile von FIRE auf x91 nachgebaut.
Erhöhtes Risiko, wenn bis Ende 2016 fertig sein muss

# Projekt Redesign IS-LSVA relevante Arbeiten (für die Migration)
## Auswirkungen
## Abhängigkeiten
## Realisierbarkeit
## Planung - Termine
## Kosten
## Risiken
## Welche Aufwände/Arbeiten werden Über das Projekt resp. Über EFV finanziert, welche Über EZV?
## Empfehlung inkl. Vor- und Nachteilen

# Migration aktuelle EZV-Lösungen (nur FIRE)
## Auswirkungen
## Abhängigkeiten
## Realisierbarkeit
## Planung - Termine
## Kosten
## Risiken
## Welche Aufwände/Arbeiten werden Über das Projekt resp. Über EFV finanziert, welche Über EZV?
## Empfehlung inkl. Vor- und Nachteilen
