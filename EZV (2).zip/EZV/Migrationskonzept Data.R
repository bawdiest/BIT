Cube_DS <- read.csv("data/DataSource_Cube_Relation.csv", sep=";")
Rep_Cube <- read.csv("data/Report_Query_Cube_Relation.csv", sep=";")
DS_x91 <- read.csv("data/DataSources_on_x91.csv", sep=";")

Rep_DS <- merge(Rep_Cube, Cube_DS)